<?php
$connect=mysqli_connect('mysql.hostinger.in','u680633307_user','bitsmun15','u680633307_reg');
 
if(mysqli_connect_errno($connect))
{
	echo 'Failed to connect';
}

?>