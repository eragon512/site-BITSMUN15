<?php include 'database.php'; ?>

<?php

	$name = strip_tags($_POST['name']);
	$college = strip_tags($_POST['college']);
	$email = strip_tags($_POST['email']);
	$phone_no = strip_tags($_POST['phone_no']);
	$fb_id = strip_tags($_POST['fb_id']);
    $no_del = strip_tags($_POST['no_del']);
	$exp_del = strip_tags($_POST['exp_del']);
    $no_eb = strip_tags($_POST['no_eb']);
	$exp_eb = strip_tags($_POST['exp_eb']);
	$exp_oc = strip_tags($_POST['exp_oc']);
	$exp_other = strip_tags($_POST['exp_other']);
	$com_pref_1 = $_POST['com_pref_1'];
	$pos_pref_1 = $_POST['pos_pref_1'];
	$com_pref_2 = $_POST['com_pref_2'];
	$pos_pref_2 = $_POST['pos_pref_2'];
	$pref_ren = strip_tags($_POST['pref_rsn']);

	mysqli_query($connect, "INSERT INTO Executive_Board VALUES('$name','$college','$phone_no','$email','$fb_id','$no_del','$exp_del','$no_eb','$exp_eb','$exp_oc','$exp_other','$com_pref_1','$pos_pref_1','$com_pref_2','$pos_pref_2','$pref_ren')");

	if(mysqli_affected_rows($connect) > 0);
	else
	{
		echo mysqli_error ($connect);
	}

?>