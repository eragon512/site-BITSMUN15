<?php include 'database.php'; ?>

<?php

	$name = strip_tags($_POST['name']);
	$college = strip_tags($_POST['college']);
	$email = strip_tags($_POST['email']);
	$phone_no = strip_tags($_POST['phone_no']);
	$fb_id = strip_tags($_POST['fb_id']);
    $no_press = strip_tags($_POST['no_press']);
	$exp_press = strip_tags($_POST['exp_press']);
    $no_del = strip_tags($_POST['no_del']);
	$exp_del = strip_tags($_POST['exp_del']);
	$exp_oc = strip_tags($_POST['exp_oc']);
	$exp_other = strip_tags($_POST['exp_jour']);
	$why_me = strip_tags($_POST['why_me']);

	mysqli_query($connect, "INSERT INTO IP_Head VALUES('$name','$college','$phone_no','$email','$fb_id','$no_press','$exp_press','$no_del','$exp_del','$exp_oc','$exp_other','$why_me')");

	if(mysqli_affected_rows($connect) > 0);
	else
	{
		echo mysqli_error ($connect);
	}

?>